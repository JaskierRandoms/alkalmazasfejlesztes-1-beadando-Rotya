﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Phonebook
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        private Contact currentContact;

        public Window2(Contact contact)
        {
            InitializeComponent();
            currentContact = contact;
            W2TBnev.Text = currentContact.nev;
            W2TBnum.Text = currentContact.number;
            if (currentContact.type.Equals("Mobil"))
                W2CB.SelectedIndex = 1;
            else
                W2CB.SelectedIndex = 0;
        }

        private void W2Button_Click(object sender, RoutedEventArgs e)
        {
            Connection.EditUser(W2TBnev,W2TBnum,W2CB,currentContact.id);
            Close();
        }

    }
}
