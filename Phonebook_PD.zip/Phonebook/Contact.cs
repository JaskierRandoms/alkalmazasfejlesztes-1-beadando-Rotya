﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phonebook
{
    public partial class Contact
    {
        public int id;
        public string nev;
        public string number;
        public string type;

        public Contact(int id,string nev,string number,string type)
        {
            this.id = id;
            this.nev = nev;
            this.number = number;
            this.type = type;

        }
        public string LongString()
        {
            return nev + " " + number + " " + type;
        }
        public string ShortString()
        {
            return nev;
        }
        
    }
}
