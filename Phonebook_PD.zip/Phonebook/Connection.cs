﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;
using System.Collections;

namespace Phonebook
{
    class Connection
    {
            private static MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=phonebook");
            public static void Connect()
            {
                try
                {
                    conn.Open();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            public static void CloseConnection()
            {
                conn.Close();
            }
        public static void AddUser(TextBox tbnev,TextBox tbtelefon,ComboBox comboBox)
        {
            Connect();
            string str = "INSERT INTO contacts(id, name, number, type) VALUES(NULL, '" + tbnev.Text + "','" + tbtelefon.Text + "', '" + comboBox.Text + "')";
            MySqlCommand cmd = new MySqlCommand(str, conn);
            if (tbnev.Text != null && tbtelefon.Text != null && comboBox.Text != null)
            {
                cmd.ExecuteNonQuery();
            }
            else
            {
                MessageBox.Show("Please fill the fields!");
            }
            CloseConnection();
        }

        public static Contact[] GetAllUser()
        {
            Connect();
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT id, name, number, type FROM contacts", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            Contact[] c = new Contact[ds.Tables[0].Rows.Count];
            int i = 0;
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                Contact contact = new Contact(
                    int.Parse(row["id"].ToString()),
                    row["name"].ToString(),
                    row["number"].ToString(),
                    row["type"].ToString()
                );
                c[i] = contact;
                i++;
                
            }
            CloseConnection();
            return c;
        }

        public static void DeleteUser(int id)
        {
            Connect();
            string str = "DELETE FROM contacts WHERE contacts.id = " + id;
            MySqlCommand cmd = new MySqlCommand(str, conn);
            cmd.ExecuteNonQuery();
            CloseConnection();
            MessageBox.Show("Elérhetőség eltávolítva!");
            
            
        }
        public static void EditUser(TextBox w2nev,TextBox w2num,ComboBox cb, int id)
        {
            Connect();
            if (w2nev.Text != "" && w2num.Text != "")
            {
                string str = string.Format("UPDATE contacts SET name='{0}',number='{1}',type='{2}' WHERE id = {3}", w2nev.Text, w2num.Text, cb.Text, id);
                MySqlCommand cmd = new MySqlCommand(str, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Elérhetőség módosítva!");
            }
            else
            {
                MessageBox.Show("Kérem töltse ki az összes mezőt!");
            }
            CloseConnection();
        }
    }
}
