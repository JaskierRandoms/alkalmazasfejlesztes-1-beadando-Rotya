﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Phonebook
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private bool IsDeatliedView = false;
        private Contact[] tomb;
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void UjButton_Click(object sender, RoutedEventArgs e)
        {
            Window1 ujablak = new Window1();
            ujablak.Show();
        }
        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);
            Refresh();
        }

        private void ReszletButton_Click(object sender, RoutedEventArgs e)
        {
            IsDeatliedView = !IsDeatliedView;
            Refresh();
        }
        private void Refresh()
        {
            tomb = Connection.GetAllUser();
            ListBox.Items.Clear();
            if (IsDeatliedView)
            {
                ReszletButton.Content = "Minimalista nezet";
                foreach (Contact contact in tomb)
                {
                    ListBoxItem lbi = new ListBoxItem();
                    lbi.Content = contact.LongString();
                    ListBox.Items.Add(lbi);
                }

            }
            else
            {
                ReszletButton.Content = "Reszletes nezet";
                foreach (Contact contact in tomb)
                {
                    ListBoxItem lbi = new ListBoxItem();
                    lbi.Content = contact.ShortString();
                    ListBox.Items.Add(lbi);
                }
            }
        }

        private void TorlesButton_Click(object sender, RoutedEventArgs e)
        {
            if (ListBox.SelectedItem != null)
            {
                Connection.DeleteUser(tomb[ListBox.SelectedIndex].id);
                ListBox.ItemsSource = null;
                ListBox.Items.Clear();
            }
            else
                MessageBox.Show("Válaszd ki a törölni kívánt elérhetőséget!");
            Refresh();
        }

        private void SzerkButton_Click(object sender, RoutedEventArgs e)
        {
            

            if (ListBox.SelectedItem != null)
            {
                Window2 ujablak2 = new Window2(tomb[ListBox.SelectedIndex]);
                ujablak2.Show();
            }
            else
            {
                MessageBox.Show("Válaszd ki a modositani kívánt elérhetőséget!");
            }
        }
    }
}
