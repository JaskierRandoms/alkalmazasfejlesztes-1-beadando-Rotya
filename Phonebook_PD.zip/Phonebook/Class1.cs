﻿using System;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace Phonebook
{

    public class Connection
    {
        private MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=phonebook");
        public void Connect()
        {
            try
            {
                conn.Open();
                Console.WriteLine("Connection is " + conn.State.ToString());
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Error: " + ex.Message.ToString());
            }
        }
        public void CloseConnection()
        {
            conn.Close();
            Console.WriteLine("Connection is " + conn.State.ToString());
        }

    }
}
